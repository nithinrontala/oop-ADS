from sol import ArrayListADT
class Transaction:
    def __init__(self):
        self.type = ""
        self.amount = 0.0
        self.fee = 0.025

    def TransactionFee(self):
        self.f = self.amount * self.fee
        self.remaining = self.amount - self.f


class Wallet:
    # p=Transaction()
    def __init__(self):
        self.t = Transaction()
        self.a = self.t.amount
        self.fee = 0.0
        self.totalAmount = 0.0
        self.TransactionHis = ArrayListADT()  
        
    def iniWallet(self, a, b):
        self.limit = float(a)
        self.fee = float(b) / 100
        print(f"Wallet initialized with withdrawalLimit: {int(a):.1f}, withdrawalFeePercentage: {float(b)}%")

    def deposit(self, amount):
        fee = 0.0
        d = "DEPOSIT"
        if amount < 0:
            return f"Deposit of {float(amount)} failed. Balance remains: {self.totalAmount}"
        else:
            self.totalAmount += amount
            self.getTransactions((d, amount, fee))
            return f"Deposit of {float(amount)} successful. Current balance: {self.totalAmount}"

    def withdraw(self, amount):
        if self.limit < amount or self.totalAmount < amount:
            return f"Withdrawal of {float(amount)} failed. Balance remains: {self.totalAmount}"
        else:
            w = "WITHDRAW"
            self.withdrawalFee(amount)
            self.getTransactions((w, amount, self.f))
            return f"Withdrawal of {float(amount)} successful with a fee of {self.f}. Current balance: {self.totalAmount}"

    def getBalance(self):
        return f"Current Balance: {self.totalAmount}"

    def getTransactions(self, a):
        self.TransactionHis.add(a)  

    def Transtaction(self):
        trans = "Transaction History:\n"
        if self.TransactionHis.is_empty():
            return trans
        for i in range(self.TransactionHis.size_()):
            t = self.TransactionHis.get(i)  
            trans += f"{i+1}. {t[0]} {t[1]:.1f} (Fee: {t[2]})\n"
        return trans

    def withdrawalFee(self, amount):
        self.f = amount * self.fee
        self.totalAmount -= amount
        self.totalAmount -= self.f
        return [self.totalAmount, self.f]

    def runWallet(self):
        while True:
            try:
                s = input().split()
                if s[0] == "deposit":
                    print(self.deposit(float(s[1])))
                elif s[0] == "withdraw":
                    print(self.withdraw(float(s[1])))
                elif s[0] == "getBalance":
                    print(self.getBalance())
                elif s[0] == "getTransactions":
                    print(self.Transtaction())
                else:
                    self.iniWallet(s[0], s[1])
            except:
                break


if __name__ == "__main__":
    r = Wallet()
    r.runWallet()
